import os
import cv2
import numpy as np
import tensorflow as tf
from flask import Flask, request, render_template, send_from_directory, redirect, url_for

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['OUTPUT_FOLDER'] = 'static/output/'

# Update the model path to the correct one
MODEL_PATH = 'my_model (1).h5'

# Load the pre-trained model
try:
    model = tf.keras.models.load_model(MODEL_PATH)
    print("Model loaded successfully.")
except FileNotFoundError:
    print(f"Model file not found at {MODEL_PATH}. Please check the path.")
    model = None

def predict_label_and_name(image_path, model):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = cv2.resize(image, (100, 100))
    image = image.reshape(1, 100, 100, 1)
    image = image.astype('float32') / 255

    prediction = model.predict(image)
    predicted_label = np.argmax(prediction, axis=1)[0]
    label_map = {0: 'Akshay Kumar Jain', 1: 'Aryan Garg', 2: 'Nipun Rajput', 3: 'Arun Singh Rajpurohit'}
    predicted_class_name = label_map[predicted_label]

    return predicted_label, predicted_class_name

def display_image_with_prediction(image_path, predicted_class_name, face_coordinates):
    image = cv2.imread(image_path)
    x, y, w, h = face_coordinates
    top_left = (x, y)
    bottom_right = (x + w, y + h)
    color = (0, 255, 0)
    thickness = 2
    cv2.rectangle(image, top_left, bottom_right, color, thickness)
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    font_color = (255, 255, 255)
    text_thickness = 2
    text_org = (x, y + h + 30)
    cv2.putText(image, predicted_class_name, text_org, font, font_scale, font_color, text_thickness)
    output_path = os.path.join(app.config['OUTPUT_FOLDER'], 'result.png')
    cv2.imwrite(output_path, image)
    return output_path

def process_video_in_chunks(video_path, output_path, chunk_size=100):
    cap = cv2.VideoCapture(video_path)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = None
    frame_count = 0

    while cap.isOpened():
        frames = []
        for _ in range(chunk_size):
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)

        if len(frames) == 0:
            break

        enhanced_frames = [enhance_frame(frame) for frame in frames]

        if out is None:
            h, w, _ = enhanced_frames[0].shape
            out = cv2.VideoWriter(output_path, fourcc, 25, (w, h))

        for frame in enhanced_frames:
            out.write(frame)

        frame_count += len(frames)
        print(f"Processed {frame_count} frames")

    cap.release()
    if out is not None:
        out.release()

def enhance_frame(frame):
    yuv = cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)
    y, u, v = cv2.split(yuv)
    y = cv2.fastNlMeansDenoising(y, None, h=10, templateWindowSize=7, searchWindowSize=21)
    yuv = cv2.merge((y, u, v))
    enhanced_frame = cv2.cvtColor(yuv, cv2.COLOR_YUV2BGR)
    alpha = 1.15
    beta = 15
    enhanced_frame = cv2.convertScaleAbs(enhanced_frame, alpha=alpha, beta=beta)
    enhanced_frame = cv2.resize(enhanced_frame, (1920, 1080), interpolation=cv2.INTER_CUBIC)
    return enhanced_frame

@app.route('/')
def main_page():
    return render_template('main.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/super')
def super_page():
    return render_template('super.html')

@app.route('/upload_image', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        if model is None:
            return 'Model not loaded. Please check the server logs.'
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        face_coordinates = (450, 250, 200, 200)  # Dummy face coordinates, replace with actual coordinates

        predicted_label, predicted_class_name = predict_label_and_name(file_path, model)
        result_path = display_image_with_prediction(file_path, predicted_class_name, face_coordinates)
        
        return render_template('result.html', filename='result.png')

@app.route('/upload_video', methods=['POST'])
def upload_video():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        output_path = os.path.join(app.config['OUTPUT_FOLDER'], 'enhanced_' + file.filename)
        
        process_video_in_chunks(file_path, output_path)
        
        return render_template('result_video.html', filename='enhanced_' + file.filename)

@app.route('/download/<filename>')
def download_file(filename):
    return render_template('download.html', filename=filename)

@app.route('/files/<filename>')
def files(filename):
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    if not os.path.exists(app.config['OUTPUT_FOLDER']):
        os.makedirs(app.config['OUTPUT_FOLDER'])
    app.run(debug=True)
